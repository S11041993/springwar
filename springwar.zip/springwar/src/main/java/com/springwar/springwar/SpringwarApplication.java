package com.springwar.springwar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringwarApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringwarApplication.class, args);
	}

}
