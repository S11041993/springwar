package com.springwar.springwar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringwarApplicationTests {

	@Test
	void contextLoads() {
	}

}
